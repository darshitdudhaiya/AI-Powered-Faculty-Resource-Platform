# AI-Powered-Faculty-Resource-Platform
